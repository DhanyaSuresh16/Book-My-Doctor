package com.Service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.Service.FeedbackService;
import com.Entity.Feedback;
import com.Repository.FeedbackRepository;

@SpringBootTest
class FeedBackServiceTest {

	
	@Autowired
	FeedbackService feedbackservice;
	
	@MockBean
	FeedbackRepository repo;

	@Test
	void testGetFeedBackList() {
		Feedback c1=new Feedback();
		c1.setFeedbackId(1);
		c1.setFeedback_details("Excellent");
		c1.setRating(5);
		
		Feedback c2=new Feedback();
		c2.setFeedbackId(2);
		c2.setFeedback_details("Good");
		c2.setRating(4);
		
		List<Feedback> FeedBackList = new ArrayList<>();
		FeedBackList.add(c1);
		FeedBackList.add(c2);
		
		Mockito.when(repo.findAll()).thenReturn(FeedBackList);
		
		assertThat(feedbackservice.getAllFeedback()).isEqualTo(FeedBackList);
	}
	
	@Test
	void testAddFeedBack() {
		Feedback c1=new Feedback();
		c1.setFeedbackId(1);
		c1.setFeedback_details("Excellent");
		c1.setRating(5);
	Mockito.when(repo.save(c1)).thenReturn(c1);
		
		assertThat(feedbackservice.addFeedback(c1)).isEqualTo(c1);
	}
	
}
